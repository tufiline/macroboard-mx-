console.log('✅ auth.js cargado');

const AuthService = {
    currentUser: null,
    isAuthenticated: false,

    // Simular autenticación
    login: function(username, password) {
        console.log('AuthService: Intentando login...');
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // Simular credenciales válidas
                if (username === 'admin' && password === 'password') {
                    this.currentUser = {
                        username: username,
                        role: 'admin',
                        token: 'mock-jwt-token-' + Date.now()
                    };
                    this.isAuthenticated = true;
                    console.log('AuthService: Login exitoso', this.currentUser);
                    resolve(this.currentUser);
                } else {
                    this.isAuthenticated = false;
                    reject(new Error('Credenciales inválidas'));
                }
            }, 500);
        });
    },

    // Verificar autenticación
    checkAuth: function() {
        console.log('AuthService: Verificando autenticación...');
        // En una app real, verificaría el token JWT
        return this.isAuthenticated;
    },

    // Obtener headers de autorización
    getAuthHeaders: function() {
        if (this.currentUser && this.currentUser.token) {
            return {
                'Authorization': 'Bearer ' + this.currentUser.token,
                'Content-Type': 'application/json'
            };
        }
        return {};
    },

    // Cerrar sesión
    logout: function() {
        console.log('AuthService: Cerrando sesión...');
        this.currentUser = null;
        this.isAuthenticated = false;
    }
};

console.log('AuthService inicializado');