// data.js - Servicio de Datos Corregido
class DataStorage {
    static async getConfig() {
        try {
            const config = localStorage.getItem('macroboard_config');
            return config ? JSON.parse(config) : {};
        } catch (error) {
            console.error('Error obteniendo configuración:', error);
            return {};
        }
    }

    static async saveConfig(config) {
        try {
            const current = await this.getConfig();
            const merged = { ...current, ...config };
            localStorage.setItem('macroboard_config', JSON.stringify(merged));
            return merged;
        } catch (error) {
            console.error('Error guardando configuración:', error);
            return {};
        }
    }

    static async getUsers() {
        try {
            const users = localStorage.getItem('macroboard_users');
            return users ? JSON.parse(users) : {};
        } catch (error) {
            console.error('Error obteniendo usuarios:', error);
            return {};
        }
    }

    static async saveUsers(users) {
        try {
            localStorage.setItem('macroboard_users', JSON.stringify(users));
            return users;
        } catch (error) {
            console.error('Error guardando usuarios:', error);
            return {};
        }
    }
}

// Verificar que la clase esté disponible
console.log('✅ DataStorage cargado correctamente');
window.DataStorage = DataStorage;