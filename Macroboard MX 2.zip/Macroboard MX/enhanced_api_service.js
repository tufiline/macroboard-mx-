console.log('✅ enhanced_api_service.js cargado');

const EnhancedApiService = {
    baseURL: 'https://jsonplaceholder.typicode.com',
    retryCount: 3,
    timeout: 5000,

    init: function() {
        console.log('EnhancedApiService inicializado');
        this.setupInterceptors();
    },

    setupInterceptors: function() {
        console.log('Configurando interceptores de API...');
    },

    // Método genérico para requests HTTP
    request: async function(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        console.log(`API: Solicitando ${url}`);

        const config = {
            method: options.method || 'GET',
            headers: {
                'Content-Type': 'application/json',
                ...AuthService.getAuthHeaders(),
                ...options.headers
            },
            timeout: this.timeout
        };

        if (options.data) {
            config.body = JSON.stringify(options.data);
        }

        for (let attempt = 1; attempt <= this.retryCount; attempt++) {
            try {
                console.log(`Intento ${attempt} para ${endpoint}`);
                
                const response = await fetch(url, config);
                
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data = await response.json();
                console.log(`API: Respuesta exitosa de ${endpoint}`, data);
                return data;

            } catch (error) {
                console.error(`Intento ${attempt} falló:`, error.message);
                
                if (attempt === this.retryCount) {
                    throw new Error(`API request failed after ${this.retryCount} attempts: ${error.message}`);
                }
                
                // Esperar antes de reintentar
                await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
            }
        }
    },

    // Métodos específicos
    get: function(endpoint) {
        return this.request(endpoint, { method: 'GET' });
    },

    post: function(endpoint, data) {
        return this.request(endpoint, { method: 'POST', data });
    },

    // Obtener datos de usuarios (ejemplo)
    fetchUsers: function() {
        return this.get('/users');
    },

    // Obtener posts (ejemplo)
    fetchPosts: function() {
        return this.get('/posts');
    }
};

// Inicializar el servicio
EnhancedApiService.init();