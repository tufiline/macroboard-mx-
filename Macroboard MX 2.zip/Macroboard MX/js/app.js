console.log('✅ app.js cargado');

const App = {
    init: function() {
        console.log('=== APLICACIÓN INICIADA ===');
        
        // Verificar que todas las dependencias estén cargadas
        this.checkDependencies();
        
        // Inicializar componentes principales
        this.initializeComponents();
        
        // Configurar manejadores globales
        this.setupGlobalHandlers();
        
        console.log('=== APLICACIÓN CONFIGURADA CORRECTAMENTE ===');
    },

    checkDependencies: function() {
        const dependencies = {
            DataService: typeof DataService !== 'undefined',
            AuthService: typeof AuthService !== 'undefined',
            EnhancedApiService: typeof EnhancedApiService !== 'undefined',
            EnhancedDashboard: typeof EnhancedDashboard !== 'undefined'
        };

        console.log('Verificando dependencias:', dependencies);

        const missing = Object.keys(dependencies).filter(key => !dependencies[key]);
        
        if (missing.length > 0) {
            throw new Error(`Dependencias faltantes: ${missing.join(', ')}`);
        }
    },

    initializeComponents: function() {
        console.log('Inicializando componentes de la aplicación...');
        
        // El dashboard se auto-inicializa, pero podemos agregar configuraciones adicionales
        if (EnhancedDashboard && typeof EnhancedDashboard.init === 'function') {
            console.log('Dashboard listo y auto-inicializado');
        }
        
        // Podemos inicializar otros componentes aquí
        this.setupTheme();
    },

    setupGlobalHandlers: function() {
        console.log('Configurando manejadores globales...');
        
        // Manejador de errores global
        window.addEventListener('error', (event) => {
            console.error('Error global capturado:', event.error);
        });

        // Manejador para errores de promesas no capturadas
        window.addEventListener('unhandledrejection', (event) => {
            console.error('Promesa rechazada no capturada:', event.reason);
        });
    },

    setupTheme: function() {
        // Sistema simple de temas
        const savedTheme = localStorage.getItem('dashboard-theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
        console.log('Tema configurado:', savedTheme);
    },

    // Métodos de utilidad globales
    utils: {
        formatNumber: function(num) {
            return new Intl.NumberFormat().format(num);
        },
        
        formatCurrency: function(amount, currency = 'USD') {
            return new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: currency
            }).format(amount);
        },
        
        debounce: function(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
    }
};

// Inicializar la aplicación cuando todo esté listo
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        App.init();
    });
} else {
    App.init();
}

// Hacer utilidades disponibles globalmente
window.AppUtils = App.utils;