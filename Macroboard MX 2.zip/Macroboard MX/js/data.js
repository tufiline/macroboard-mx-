console.log('✅ data.js cargado');

const DataService = {
    // Datos de ejemplo
    sampleData: {
        users: 142,
        sales: 12500,
        performance: 87.5,
        trends: [65, 78, 90, 87, 93, 88, 95]
    },

    // Simular llamada a API
    fetchData: function() {
        console.log('DataService: Solicitando datos...');
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // Simular éxito 90% del tiempo
                if (Math.random() > 0.1) {
                    const data = {
                        ...this.sampleData,
                        timestamp: new Date().toLocaleTimeString(),
                        activeUsers: Math.floor(Math.random() * 200) + 100,
                        salesToday: Math.floor(Math.random() * 20000) + 5000
                    };
                    console.log('DataService: Datos obtenidos', data);
                    resolve(data);
                } else {
                    reject(new Error('Error simulado al obtener datos'));
                }
            }, 1000);
        });
    },

    // Procesar datos
    processData: function(rawData) {
        return {
            activeUsers: rawData.activeUsers,
            salesToday: `$${rawData.salesToday.toLocaleString()}`,
            performance: `${rawData.performance}%`,
            lastUpdate: rawData.timestamp
        };
    },

    // Exportar datos
    exportToCSV: function(data) {
        const csvContent = [
            'Métrica,Valor',
            `Usuarios Activos,${data.activeUsers}`,
            `Ventas Hoy,${data.salesToday}`,
            `Rendimiento,${data.performance}`,
            `Actualizado,${data.lastUpdate}`
        ].join('\n');
        
        return csvContent;
    }
};

console.log('DataService inicializado');