console.log('✅ enhanced_dashboard.js cargado');

const EnhancedDashboard = {
    config: {
        autoRefresh: true,
        refreshInterval: 30000, // 30 segundos
        theme: 'light'
    },
    
    elements: {},
    refreshInterval: null,

    init: function() {
        console.log('EnhancedDashboard creado');
        this.cacheElements();
        this.bindEvents();
        this.loadInitialData();
        this.setupAutoRefresh();
    },

    cacheElements: function() {
        console.log('Cacheando elementos del DOM...');
        this.elements = {
            loading: document.getElementById('loading'),
            errorContainer: document.getElementById('error-container'),
            dashboardContent: document.getElementById('dashboard-content'),
            activeUsers: document.getElementById('active-users'),
            salesToday: document.getElementById('sales-today'),
            performance: document.getElementById('performance'),
            refreshBtn: document.getElementById('refresh-btn'),
            exportBtn: document.getElementById('export-btn')
        };
    },

    bindEvents: function() {
        console.log('Configurando event listeners...');
        
        if (this.elements.refreshBtn) {
            this.elements.refreshBtn.addEventListener('click', () => {
                this.refreshData();
            });
        }

        if (this.elements.exportBtn) {
            this.elements.exportBtn.addEventListener('click', () => {
                this.exportData();
            });
        }
    },

    loadInitialData: async function() {
        console.log('Cargando datos iniciales...');
        
        try {
            // Verificar autenticación primero
            if (!AuthService.checkAuth()) {
                console.log('Usuario no autenticado, simulando login...');
                await AuthService.login('admin', 'password');
            }

            await this.refreshData();
            
        } catch (error) {
            this.showError('Error al cargar datos iniciales: ' + error.message);
        }
    },

    refreshData: async function() {
        console.log('Actualizando datos del dashboard...');
        
        this.showLoading();
        this.hideError();

        try {
            // Obtener datos del servicio
            const rawData = await DataService.fetchData();
            const processedData = DataService.processData(rawData);
            
            // Actualizar UI
            this.updateUI(processedData);
            this.showContent();
            
            console.log('Dashboard actualizado exitosamente');
            
        } catch (error) {
            this.showError('Error al actualizar datos: ' + error.message);
            this.showContent(); // Mostrar contenido aunque haya error
        }
    },

    updateUI: function(data) {
        console.log('Actualizando interfaz de usuario...', data);
        
        if (this.elements.activeUsers && data.activeUsers) {
            this.elements.activeUsers.textContent = data.activeUsers;
        }
        
        if (this.elements.salesToday && data.salesToday) {
            this.elements.salesToday.textContent = data.salesToday;
        }
        
        if (this.elements.performance && data.performance) {
            this.elements.performance.textContent = data.performance;
        }
    },

    exportData: async function() {
        console.log('Exportando datos...');
        
        try {
            const rawData = await DataService.fetchData();
            const csvContent = DataService.exportToCSV(DataService.processData(rawData));
            
            // Crear y descargar archivo
            const blob = new Blob([csvContent], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `dashboard-export-${new Date().toISOString().split('T')[0]}.csv`;
            a.click();
            window.URL.revokeObjectURL(url);
            
            console.log('Datos exportados exitosamente');
            
        } catch (error) {
            this.showError('Error al exportar datos: ' + error.message);
        }
    },

    setupAutoRefresh: function() {
        if (this.config.autoRefresh) {
            console.log('Configurando auto-refresh cada', this.config.refreshInterval, 'ms');
            this.refreshInterval = setInterval(() => {
                this.refreshData();
            }, this.config.refreshInterval);
        }
    },

    showLoading: function() {
        if (this.elements.loading) {
            this.elements.loading.style.display = 'block';
        }
        if (this.elements.dashboardContent) {
            this.elements.dashboardContent.style.display = 'none';
        }
    },

    showContent: function() {
        if (this.elements.loading) {
            this.elements.loading.style.display = 'none';
        }
        if (this.elements.dashboardContent) {
            this.elements.dashboardContent.style.display = 'block';
        }
    },

    showError: function(message) {
        console.error('Error en dashboard:', message);
        
        if (this.elements.errorContainer) {
            this.elements.errorContainer.innerHTML = `
                <div class="error">
                    <strong>Error:</strong> ${message}
                </div>
            `;
            this.elements.errorContainer.style.display = 'block';
        }
    },

    hideError: function() {
        if (this.elements.errorContainer) {
            this.elements.errorContainer.style.display = 'none';
        }
    },

    destroy: function() {
        console.log('Limpiando dashboard...');
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }
    }
};

console.log('EnhancedDashboard configurado para auto-inicializacion');

// Auto-inicialización cuando el DOM esté listo
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        EnhancedDashboard.init();
    });
} else {
    EnhancedDashboard.init();
}